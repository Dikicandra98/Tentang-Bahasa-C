#include <stdio.h>

int main() {
    char nama[50];
    printf("Masukkan nama Anda: ");
    scanf("%[^\n]", nama);
    printf("Nama Anda adalah: %s", nama);

    return 0;
}
