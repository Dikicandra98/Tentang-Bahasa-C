#include <stdio.h>

struct Mahasiswa {
    char nim[15];
    char nama[50];
    int umur;
};

void main() {
    struct Mahasiswa mhs;

    printf("Masukkan NIM: ");
    scanf("%[^\n]s", &mhs.nim);
    printf("Masukkan Nama: ");
    scanf("%[^\n]s",&mhs.nama);
    printf("Masukkan Umur: ");
    scanf("%[^\n]d", &mhs.umur);

    printf("\nData Mahasiswa\n");
    printf("NIM: %s\n", mhs.nim);
    printf("Nama: %s\n", mhs.nama);
    printf("Umur: %d", mhs.umur);


}
