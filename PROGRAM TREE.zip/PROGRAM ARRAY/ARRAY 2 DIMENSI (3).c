#include <stdio.h>

int main(){

  char hewan[3][5] ={
  {"ikan"}, //baris ke 1
  {"sapi"}, // baris ke 2
  {"ayam"} // baris ke 3
  };

/*untuk mencetak array character 2 dimensi
    menggunakan 1 kali loop
*/
  for(int i=0; i<3; i++){
    printf("%s ", hewan[i]);
  }
  puts("");
  return 0;
}
