#include <stdio.h>
//for
void main(){
    for (int i=0; i<10; i++){
        printf ("zia terlalu op!\n\n");

    }
}
