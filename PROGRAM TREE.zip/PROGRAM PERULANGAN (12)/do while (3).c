#include <stdio.h>

//membuat tabel konversi temperatur//

main()
{
int f,r,k, no,c;
printf(" No.");
printf(" celsius");
printf(" farenheit");
printf(" reamur");
printf(" kelvin");

for(no=1,c=0;c<=100,no<=10;no++,c+=10)
{
printf("\n\n%5d %5d",no,c);
f=9*c/5+32;
r=4*c/5;
k=c+273;
printf(" %5d %5d %5d",f,r,k);

}
getch();
}
