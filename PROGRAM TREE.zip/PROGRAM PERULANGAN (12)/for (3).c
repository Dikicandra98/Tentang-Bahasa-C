 #include <stdio.h>

void  main ()
{
    int i,x,t;
    int total=1;

    printf("masukan bilangan yang akan di pangkat :");
    scanf("%d", &x);
    printf("masukan bialngan bilangan pangkatnya :");
    scanf("%d", &t);

    for (i=0;i<=t;i++){
            total = total*x;
    }

    printf("\nbilangan  hasil : %d\n",total);


}
