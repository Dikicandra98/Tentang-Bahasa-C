#include <stdio.h>

void main (){
	for (char i='A'; i<='Z'; i++)
	printf("%c", i);


	}
