#include <stdio.h>

void main (){

	int i=10;

	while(i>=1){
		printf("%d", i);
		i--;
		}

	}
