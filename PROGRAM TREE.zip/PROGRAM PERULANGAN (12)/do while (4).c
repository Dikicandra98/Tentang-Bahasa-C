#include <stdio.h>

main()
{
int a, b, c, d;
printf("Masukkan bilangan bulat positif = ");
scanf("%d", &a);
while(a>0)
{
printf("\nJumlah angka dalam bilangan = %d", a);
printf("%d", a%10);
a = ( a - a%10 )/10;
}

getch();
}
