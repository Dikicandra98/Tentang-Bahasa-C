 /* Program : ptr7.c */
 #include <stdio.h>

 main()
 {
     /*pkota menunjuk konstanta string "SEMARANG" */
     char *pkota = "SEMARANG";

     printf ("string yang ditunjuk oleh pkota = ");
     puts(pkota);
 }
