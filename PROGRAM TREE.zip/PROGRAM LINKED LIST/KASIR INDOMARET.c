#include <stdio.h>
#include <stdlib.h>

struct Item {
    char nama[50];
    int harga;
    int jumlah;
    struct Item* next;
};

struct Kasir {
    struct Item* head;
    int total;
};

void push_item(struct Kasir* kasir, char nama[50], int harga, int jumlah) {
    struct Item* new_item = (struct Item*) malloc(sizeof(struct Item));
    new_item->harga = harga;
    new_item->jumlah = jumlah;
    strcpy(new_item->nama, nama);
    new_item->next = kasir->head;
    kasir->head = new_item;
    kasir->total += harga * jumlah;
}

void cetak_daftar_belanja(struct Kasir kasir) {
    struct Item* item = kasir.head;
    printf("Daftar Belanja:\n");
    while (item != NULL) {
        printf("- %s x%d @ Rp%d = Rp%d\n", item->nama, item->jumlah, item->harga, item->harga * item->jumlah);
        item = item->next;
    }
    printf("Total Harga: Rp%d\n", kasir.total);
}

int main() {
    struct Kasir kasir;
    kasir.head = NULL;
    kasir.total = 0;

    pushitem(&kasir, "Indomie Goreng", 3000, 2);
    pushitem(&kasir, "Air Mineral", 2500, 1);
    pushitem(&kasir, "Gula", 4000);

    return 0;

}
