#include <stdio.h>

//menu makanan//

void main (){

    int Mejake;
    printf ("\nTuliskan Menu Makanan Meja Ke berapa: ");
    scanf ("%d", &Mejake);

    switch (Mejake){

    case 1:
        printf ("Meja ke 1:\n");
        printf ("\n- Nasi goreng");
        printf ("\n- Ayam penyet");
        printf ("\n- Babi guling");
        printf ("\n- steak");
        break;
    case 2:
        printf ("Meja ke 2:\n");
        printf ("\n- Sushi");
        printf ("\n- Tempura");
        printf ("\n- Sukiyaki");
        printf ("\n- Ramen");
        break;
    case 3:
        printf ("Meja ke 3:\n");
        printf ("\n- Curry rise");
        printf ("\n- Tonkatsu");
        printf ("\n- Japanese soba");
        printf ("\n- Udon");
        break;
    case 4:
        printf ("Meja ke 4:\n");
        printf ("\n- Kimchi");
        printf ("\n- Bibimbap");
        printf ("\n- Bulgogi");
        printf ("\n- Kimbab");
        break;
    case 5:
        printf ("Meja ke 5:\n");
        printf ("\n- Pizza");
        printf ("\n- Gelato");
        printf ("\n- Frites");
        printf ("\n- Currywurst");
        break;
    case 6:
        printf ("Meja ke 6:\n");
        printf ("\n- Ayam Betutu");
        printf ("\n- Sate lilit");
        printf ("\n- Mie Aceh");
        printf ("\n- Rendang");
        break;
    }


}



