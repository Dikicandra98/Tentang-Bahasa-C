#include <stdio.h>

//Studi Kasus perhitungan!(3)//

void main(){
    int x;

    printf("Masukkan nilai dari -100 hingga 100: ");
    scanf("%d", &x);

    if (x>=0 && x<=100){
        printf ("\nNilai yang anda masukkan positif!\n");
    }
    else if (x<=0 && x>-100){
        printf ("\nNilai yang anda masukkan negatif!\n");
    }

    else{
        printf("\nNilai yang anda masukkan lebih dari 100 atau lebih dari -100!\n");
    }

}

