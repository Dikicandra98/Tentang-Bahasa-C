#include <stdio.h>

//input tinggi peserta (2)//
//masukkan tinggi pria 165>200 jika anda ingin jawaban yg benar masukkan 200>300 jika ingin jawab yg salah//
//masukkan tinggi wanita 160>190 jika anda ingin jawaban yg benar masukkan 190>300 jika ingin jawab yg salah//
//pilih jenis kelamin dengan angka 1 jika anda pria dan pilih 2 jika anda perempuan//

int main(){

int p,tinggi;

printf("Program Seleksi tinggi\n");
printf("\njenis kelamin\n");
printf("1. Laki-Laki\n2. Perempuan\n\n");

printf("Pilih jenis kelamin anda : ");
scanf("%d", &p);
printf("\n");

printf("Masukkan tinggi badan anda :");
scanf("%d", &tinggi);

if(p==1){

        //UNTU INPUT TINGGI LAKI-LAKI!

    if(tinggi >=165 && tinggi <=200)
    printf("Selamat anda lolos seleksi!");

    else if(tinggi >=200 && tinggi <=300)
    printf("Maaf, Anda Tidak Lolos Seleksi Karena Tinggi Badan Anda Sudah Melampaui Ketentuan!\n");

    else{
    printf ("Tolong Masukkan Dengan Benar!\n");
    }
}
else if(p==2){

        //UNTUK INPUT TINNGI PEREMPUAN!

    if(tinggi >=160 && tinggi <=190)
    printf("Selamat anda lolos seleksi!");

    else if(tinggi >=190 && tinggi <=300)
    printf("Maaf, Anda Tidak Lolos Seleksi Karena Tinggi Badan Anda Sudah Melampaui Ketentuan!\n");

    else{
    printf ("Tolong Masukkan Dengan Benar!\n");
    }

}

else{
    printf("anjay goblok!");
    }

}
