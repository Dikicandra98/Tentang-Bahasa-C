#include <stdio.h>

int main() {


	char p ;
	printf ("Pilih Perhintungan Yang Anda Ingin kan Sesuai Kebutuhan!\n");
	printf ("a. Perkalian\nb. Pembagian\n");
	printf ("Tulis Angka a Atau b: ");
	scanf ("%c", &p);

	switch(p){


	case 'a':

	int a, b;

	a * b ;

	printf ("Masukkan Nilai: ");
	scanf("%d", &a);
	printf ("Masukkan Nilai: ");
	scanf("%d", &b);


	printf ("Hasil Dari Perkalian Di Atas Adalah: %d",  a * b );

	break;

	case 'b':

	float d, e, f;

	d / e / f;
	printf ("Masukkan Nilai: ");
	scanf("%f", &d);
	printf ("Masukkan Nilai: ");
	scanf("%f", &e);
	printf ("Masukkan Nilai: ");
	scanf("%f", &f);

	printf ("Hasil Dari Pembagian Di Atas Adalah: %.2f",  d / e / f);

	break;

	default:
	printf ("GOBLOK!\n");

		}

}
