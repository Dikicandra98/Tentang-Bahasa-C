#include <stdio.h>

//if tunggal 1//

int main(void){
    int X;
    printf("Masukkan nilai: ");
    scanf("%d", &X);

    if(X>0){
        printf("X adalah bilangan positif");
    }

}
