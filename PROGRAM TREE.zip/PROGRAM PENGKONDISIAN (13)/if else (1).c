#include <stdio.h>

//if else 1//

int main(void){
    int X;
    printf("Masukkan bilangan bulat: ");
    scanf("%d", &X);

    if(X>0){
        printf("X adalah bilangan bulat\n");
    }
    else{
        printf("X bukan bilangan bulat\n");
    }
}
