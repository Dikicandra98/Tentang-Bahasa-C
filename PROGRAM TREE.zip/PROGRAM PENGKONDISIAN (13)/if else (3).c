#include <stdio.h>

//if else 3//

void main(){

    int Y;
    printf("Masukkan bilangan bulat dari 51-100: ");
    scanf("%d", &Y);

    if(Y>50 && Y<100){
        printf("Jawaban anda benar\n");
    }
    else{
        printf("Jawaban anda salah\n");
    }
}

