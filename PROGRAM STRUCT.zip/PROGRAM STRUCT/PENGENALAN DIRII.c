#include <stdio.h>

struct DataDiri {
    char nama[50];
    int umur;
    char alamat[100];
};

int main() {
    struct DataDiri siswa;

    printf("Masukkan nama: ");
    scanf("%[^c\n]", &siswa.nama);

    printf("Masukkan umur: ");
    scanf("%[^i\n]", &siswa.umur);

    printf("Masukkan alamat: ");
    scanf("%[^c\n]", &siswa.alamat);

    printf("\nData Diri:\n");
    printf("Nama: %s\n", siswa.nama);
    printf("Umur: %d\n", siswa.umur);
    printf("Alamat: %s\n", siswa.alamat);

    return 0;
}

