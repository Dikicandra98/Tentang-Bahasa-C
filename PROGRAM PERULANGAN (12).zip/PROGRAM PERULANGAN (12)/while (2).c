#include <stdio.h>

void main (){

	int i=1;

	while(i<=10){
		printf("SAYA SUKA BELAJAR DATA STRUKTUR DAN ALGORITMA!\n");
		i++;
		}

	}
