#include <stdio.h>

int main()
{
    int normal=0,F,i;

    for(i=0;i<10;i++)
    {
    printf("saya cinta buk indra\n");
    }
}
