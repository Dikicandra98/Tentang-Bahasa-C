#include <stdio.h>

int main()
{
int i= 0, N, jumlah = 0;

do
{
printf("Masukkan Bilangan : ");
scanf("%d", &N);

jumlah += N;
printf("Jumlahnya adalah %d\n", jumlah);
i++;
} while (i<5);

return 0;
}
