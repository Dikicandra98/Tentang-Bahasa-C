/* Program : arrnama.c 
Menukarkan isi 2 string tanpa pemakaian pointer */

#include <stdio.h>
#include <string.h>

#define PANJANG 20

char nama1 [PANJANG] = "JAMES BOND";
char nama2 [PANJANG] = "HERCULE POIROT";

main()
{
		char namaX [PANJANG];
		
		puts("SEMULA : ");
		printf("Nama1 --> %s\n", nama1);
		printf("Nama2 --> %s\n", nama2);
		
		strcpy (namaX, nama1);
		strcpy (nama1, nama2);
		strcpy (nama2, namaX);
		
		puts ("KINI : ");
		
		printf("nama1 --> %s\n", nama1);
		printf("nama2 --> %s\n", nama2);
		
		
}