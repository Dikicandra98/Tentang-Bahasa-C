#include <stdio.h>

main ()
{
    int *pu;
    int nu;
    int u =1234;

    pu =&u;
    nu =*pu;

    printf("alamat dari u = %p\n", &u);
    printf("isi u         = %p\n",pu);
    printf("isi u         = %d\n",u);
    printf("nilai yang ditunjuk oleh pu = %d\n", *pu);
    printf("nilai nu      = %d\n", nu);

}