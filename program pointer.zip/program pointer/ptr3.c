#include <stdio.h>

main ()
{
    float d =54.5f, *pd;
    printf("isi d mula-mula = %g\n",d);
    pd = &d;
    *pd += 10;
    printf("isi d sekarang = %g\n",d);
}