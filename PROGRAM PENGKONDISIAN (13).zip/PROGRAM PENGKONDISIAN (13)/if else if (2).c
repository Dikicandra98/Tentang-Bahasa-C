#include <stdio.h>

//Studi Kasus Inputkan jenis kelamin!(2)//

void main(){
    int pilihan;

    printf("pilih salah satu\n1. Laki-laki\n2. Perempuan\nMasukkan pilihan anda: ");
    scanf("%d", &pilihan);

    if (pilihan == 1){
        printf ("\njenis kelamin anda laki-laki\n");
    }
    else if (pilihan == 2){
        printf ("\njenis kelamin anda Perempuan\n");
    }

    else{
        printf("\nMAAF ANDA BUKAN GOLONGAN KAMI!\n");
    }

}

