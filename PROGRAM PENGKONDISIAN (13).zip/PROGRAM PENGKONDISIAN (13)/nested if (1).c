#include <stdio.h>

//nested if (1)//

void main (){
    int nilaimtk=0;
    int nilaibing=0;
    int nilaibind=0;

    printf("Masukkan nilai Matematika: ");
    scanf("%d", &nilaimtk);
    printf("Masukkan nilai Bahasa Inggris: ");
    scanf("%d", &nilaibing);
    printf("Masukkan nilai Bahasa Inggris: ");
    scanf("%d", &nilaibind);

    if (nilaimtk >=75){

        if (nilaibing >=75){}

        if (nilaibind >=75){
            printf("Anda lulus ujian semester");
        }
    }

    else {
        printf ("\nANDA TIDAK LULUS UJIAN SEMESTER!\n");
    }
}
