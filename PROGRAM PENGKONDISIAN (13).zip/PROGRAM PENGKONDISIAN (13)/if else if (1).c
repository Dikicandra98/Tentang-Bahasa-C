#include <stdio.h>

//Studi Kasus Inputkan nilai (1)//

void main(){
    int nilai;

    printf("Masukkan Nilai Anda!: ");
    scanf("%d", &nilai);

    if (nilai >=81 & nilai <=100){
        printf("\nANDA DINYATAKAN LULUS DENGAN NILAI SEMPURNA!");
        printf ("\nNilai A\n");
    }
    else if (nilai >=71 & nilai <=80){
        printf("\nANDA DINYATAKAN LULUS DENGAN NILAI MEMUASKAN!");
        printf ("\nNilai B\n");
    }
    else if (nilai >=61 & nilai <=70){
        printf("\nANDA DINYATAKAN LULUS DENGAN NILAI CUKUP!");
        printf ("\nNilai C\n");
    }
    else{
        printf("\nMUNGKIN NILAI YG ANDA MASUKKAN LEBIH ATAU KEKURANGAN!\n");
    }

}
