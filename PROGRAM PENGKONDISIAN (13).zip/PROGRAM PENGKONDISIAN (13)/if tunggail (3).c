#include <stdio.h>

//if tunggal 3//

int main(void){
    int Y;
    printf("Masukkan nilai: ");
    scanf("%d", &Y);

    if(Y>0 && Y<100){
        printf("Benar, Nilai bilangan Y tidak lebih dari 100.\n");
    }

}
