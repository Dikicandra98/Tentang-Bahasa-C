#include <stdio.h>

//if tunggal 2//

int main(void){
    int R;
    printf("Masukkan nilai: ");
    scanf("%d", &R);

    if(R<0){
        printf("R adalah bilangan negatif");
    }

}
