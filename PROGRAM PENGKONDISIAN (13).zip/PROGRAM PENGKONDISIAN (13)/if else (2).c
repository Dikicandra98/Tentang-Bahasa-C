#include <stdio.h>

//if else 2//

void main(){

    float R;
    printf("Masukkan bilangan Desimal: ");
    scanf("%.2f", &R);

    if(R>2,3){
        printf("R adalah bilangan desimal\n");
    }
    else{
        printf("R bukan bilangan desimal\n");
    }
}
