#include <stdio.h>

//bilangan bulat (1)//

int main(void){

    int x;

    printf("Masukkan Bilangan Bulat: ");
    scanf("%d", &x);

if(x>=0 && x<=100){

    if(x<=20){
        printf("nilai x kurang dari sama dengan 20");}
    else{
        printf("nilai x lebih dari 20");}
        }
    else{
        printf("x bilangan negatif atau lebih dari 20");
        }
        }
