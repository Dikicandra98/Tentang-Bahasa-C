#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct cinta{
char *deby;
char *diki;
} sayngg;

void main(){

sayngg cinta, cintaa;

cintaa.deby="sayang kamuuu";
cintaa.diki="sayang kamu jugaa";

printf("\tkisah percintaanku bersamamu!!\n\n");
printf ("\t%s\n", cintaa.deby);
printf ("\t%s\n\n", cintaa.diki);

}
