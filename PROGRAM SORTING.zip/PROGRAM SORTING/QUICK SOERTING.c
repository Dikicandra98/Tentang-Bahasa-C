
#include <stdio.h>
#include <stdlib.h>
#define max 10000

void input();
void tukar(int *, int *);
void tampil();
void shelshort();
int data[max],hasil[max];
int n;

int main()
{

 input();
 awal=0; akhir=n-1;
 quicksort(awal,akhir)
 tampil();

}

//fungsi input

void input()
{
 int i;
 printf("Masukkan jumlah total elemen: ");
    scanf("%d",&n);

    puts(" ");
    for(i=0;i<n;i++)
 {
  data[i]=rand();
  printf("%d\t",data[i]);
  //printf("Elemen ke-%d: ",i+1);
        //scanf("%d",&data[i]);
    }
}

//fungsi quicksort

void quicksort(int L,int R)
{
 int x,j,i;
 x= data[L+R/2]; //pivot=elemen posisi pertama
    i = L ;        //inisialisasi
    j = R ;
    while(i<=j)
 {
    while(data[i] < x)
           { i++; }
   while(data[j] > x)
  { j--;}
   if (i <= j)
   {
            tukar(&data[i],&data[j]);
      j--;
   i++;
  }
 }
 if(L<j)
 {quicksort(L,j);}

 if(i<R)
 {quicksort(i,R);}


}

fungsi tampil
void tampil()
{
 int j;
 puts("\n");
 for(j=0;j<n;j++)
 {printf("%d\t",data[j]);}
 puts("\n");
}
