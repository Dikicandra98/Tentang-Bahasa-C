#include <stdio.h>
#include <stdlib.h>
#define MAX 10
int Data[MAX];
// Prosedur menukar data
void Tukar (int *a, int *b)
{
 int temp;
 temp = *a;
 *a = *b;
 *b = temp;
}

// Prosedur pengurutan metode Quick Sort
void QuickSortRekursif(int L, int R)
{
 int i, j, x;
 x = Data[(L+R)/2];
 i = L;
 j = R;
 while (i <= j){
 while(Data[i] < x)
 i++;
 while(Data[j] > x)
 j--;
 if(i <= j){
 Tukar(&Data[i], &Data[j]);
 i++;
 j--;
 }
 }
 if(L < j)
 QuickSortRekursif(L, j);
 if(i < R)
 QuickSortRekursif(i, R);
}
void main()
{
 int i;
 srand(0);

// Membangkitkan bilangan acak
 printf("DATA SEBELUM TERURUT");
 for(i=0; i<MAX; i++)
 {
 Data[i] = (int) rand()/1000+1;
 printf("\nData ke %d : %d ", i, Data[i]);
 }
 QuickSortRekursif(0, MAX-1);

 // Data setelah terurut
 printf("\nDATA SETELAH TERURUT");
 for(i=0; i<MAX; i++)
 {
 printf("\nData ke %d : %d ", i, Data[i]);
 }
}

